﻿Configuration Main
{
  param (
  $MachineName,
  $WebDeployPackagePath,
  $UserName,
  $Password
  )

  Node $MachineName
  {
    WindowsFeature WebServerRole

        {

           

            Name = "Web-Server"

            Ensure = "Present"


            }

	 


  }
} 